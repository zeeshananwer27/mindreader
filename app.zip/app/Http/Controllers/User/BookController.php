<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Book;
use App\Models\Chapter;
use App\Models\AuthorProfile;
use App\Models\Audiobook;
use App\Models\BookMedia;
use App\Models\User;
use App\Http\Requests\BookRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;

class BookController extends Controller
{
    protected $user, $subscription, $remainingBooks;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = auth_user('web');
            $this->subscription = $this->user->runningSubscription;
            $this->remainingBooks = (int)($this->subscription ? $this->subscription->remaining_books : 0);

            return $next($request);
        });
    }


    public function dashboard()
{
    $user = auth_user('web');

    // Fetch necessary data
    $totalBooks = Book::where('user_id', $user->id)->count();
    $genresCount = Book::where('user_id', $user->id)->distinct('genre')->count('genre');
    $potentialReaders = User::all()->count(); // Adjust column if necessary
    $bookGalleryCount = BookMedia::whereNotNull('file_path')->count();

    // Fetch paginated books
    $books = Book::where('user_id', $user->id)->paginate(10);

    return view('user.books.dashboard', [
        'total_books' => $totalBooks,
        'genres_count' => $genresCount,
        'potential_readers' => $potentialReaders,
        'book_gallery_count' => $bookGalleryCount,
        'books' => $books,
        'meta_data'       => $this->metaData(['title'=> translate("AI Books")]),
    ]);
}

   
    

    /**
     * Create a new book
     *
     * @return View
     */
    public function create(): View
    {
        $user = auth()->user();
        $authorProfiles = $user->authorProfiles()->get(); // Assuming a relation between users and author profiles
        $genres = get_genre_list(); // Fetch available genres
        $languages = ['English', 'German']; // Language options
        
        return view('user.books.create', [
            'meta_data' => $this->metaData(['title' => translate('Create Your Book')]),
            'authorProfiles' => $authorProfiles,
            'genres' => $genres,
            'book_languages' => $languages,
        ]);
   
    }

    /**
     * Store a new book
     *
     * @param BookRequest $request
     * @return RedirectResponse
     */
    public function store(Request $request)
    {
        $request->validate([
            'author_profile_id' => 'required|exists:author_profiles,id',
            'genre_id' => 'required|exists:genres,id',
            'purpose' => 'required|string|max:1000',
            'target_audience' => 'required|string|max:1000',
            'length' => 'required|in:small,medium,large',
            'language' => 'required|in:English,German',
        ]);
    
        $book = new Book();
        $book->user_id = auth()->id();
        $book->author_profile_id = $request->author_profile_id;
        $book->genre_id = $request->genre_id;
        $book->purpose = $request->purpose;
        $book->target_audience = $request->target_audience;
        $book->length = $request->length;
        $book->language = $request->language;
        $book->save();
    
        return redirect()->route('user.book.manager.index')->with('success', translate("Book created successfully!"));
    }
    

    /**
     * Check remaining book balance
     *
     * @return bool
     */
    public function checkRemainingBooks(): bool
    {
        return ($this->remainingBooks === -1 || $this->remainingBooks > 0);
    }

    /**
     * Show book details
     *
     * @param string $id
     * @return View
     */
    public function show(string $id): View
    {
        $book = Book::with(['chapters', 'authorProfile'])
            ->where('id', $id)
            ->where('user_id', $this->user->id)
            ->firstOrFail();

        return view('user.book.show', [
            'meta_data' => $this->metaData(['title' => translate('Book Details')]),
            'book' => $book,
        ]);
    }

    /**
     * Edit a book
     *
     * @param string $id
     * @return View
     */
    public function edit(string $id): View
    {
        $book = Book::where('id', $id)->where('user_id', $this->user->id)->firstOrFail();
        $profiles = AuthorProfile::where('user_id', $this->user->id)->get();

        return view('user.book.edit', [
            'meta_data' => $this->metaData(['title' => translate('Edit Book')]),
            'book' => $book,
            'profiles' => $profiles,
        ]);
    }

    /**
     * Update book details
     *
     * @param BookRequest $request
     * @return RedirectResponse
     */
    public function update(BookRequest $request): RedirectResponse
    {
        $book = Book::where('id', $request->id)->where('user_id', $this->user->id)->firstOrFail();
        $book->update($request->all());

        return redirect()->route('book.manager.list')->with('success', translate('Book updated successfully.'));
    }

    /**
     * Delete a book
     *
     * @param string $id
     * @return RedirectResponse
     */
    public function destroy(string $id): RedirectResponse
    {
        $book = Book::where('id', $id)->where('user_id', $this->user->id)->firstOrFail();
        $book->delete();

        return back()->with('success', translate('Book deleted successfully.'));
    }
}
